pub mod read_hold;
pub mod read_inputs;
pub mod read_param;
pub mod set_hold;
pub mod time_register_ops;
pub mod timesync;
pub mod update_hold;
pub mod write_param;
